$("#fullpage").fullpage({
  menu: "#topMenu",
  anchors: ["", "", "", "franchise", ""],
});