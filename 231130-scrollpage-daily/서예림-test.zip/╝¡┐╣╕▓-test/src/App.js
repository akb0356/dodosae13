import "./App.css";
import { useState, useRef } from "react";
import Header from "./component/Header";
import Todoeditor from "./component/Todoeditor";
import Todolist from "./component/Todolist";

const mockTodo = [
  {
    id: 0,
    isDone: false,
    content: "React 공부하기",
    createdDate: new Date().getTime(),
  },
  {
    id: 1,
    isDone: false,
    content: "빨래하기",
    createdDate: new Date().getTime(),
  },
  {
    id: 2,
    isDone: false,
    content: "숨쉬기",
    createdDate: new Date().getTime(),
  },
  {
    id: 3,
    isDone: false,
    content: "고구마먹기",
    createdDate: new Date().getTime(),
  },
];

function App() {
  const [todo, setTodo] = useState(mockTodo);
  const idRef = useRef(3);
  const onCreate = (content) => {
    const newItem = {
      id: idRef.current,
      isDone: false,
      content,
      createdDate: new Date().getTime(),
    };
    setTodo([newItem, ...todo]);
    idRef.current += 1;
  };
  return (
    <div className="App">
      <Header />
      <Todoeditor onCreate={onCreate} />
      <Todolist todo={todo} />
    </div>
  );
}

export default App;
