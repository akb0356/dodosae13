const mobGnbDrop = document.querySelectorAll(".gnb-listbox-title");
const mobGnbTitles = document.querySelectorAll(
  ".gnb-listbox-title > .title > h1"
);
const mobGnbLists = document.querySelectorAll(".gnb-list-detail");
const mobGnbDropIcons = document.querySelectorAll(
  ".gnb-listbox-title .dropicon"
);

mobGnbLists.forEach((list) => {
  list.style.height = "0";
  list.style.display = "none";
});
mobGnbTitles.forEach((title) => {
  title.style.color = "rgb(51,51,51)";
});
mobGnbDropIcons.forEach((icon) => {
  icon.style.transform = "rotate(0deg)";
});

mobGnbDrop.forEach((drop, index) => {
  drop.addEventListener("click", () => {
    const currentListHeight = mobGnbLists[index].style.height;
    const currentListDisplay = mobGnbLists[index].style.display;
    const currentTitleColor = mobGnbTitles[index].style.color;
    const currentDropIcon = mobGnbDropIcons[index].style.transform;

    mobGnbLists[index].style.height =
      currentListHeight === "0px" ? "initial" : "0px";
    mobGnbLists[index].style.display =
      currentListDisplay === "none" ? "block" : "none";
    mobGnbTitles[index].style.color =
      currentTitleColor === "rgb(51, 51, 51)"
        ? "rgb(249, 187, 0)"
        : "rgb(51, 51, 51)";
    mobGnbDropIcons[index].style.transform =
      currentDropIcon === "rotate(0deg)" ? "rotate(-180deg)" : "rotate(0deg)";
  });
});
